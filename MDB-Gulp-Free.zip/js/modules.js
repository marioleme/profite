exports.modules = [
  './js/_intro-mdb-free.js',
  './js/vendor/jquery.easing.js',
  './js/vendor/velocity.min.js',
  './js/vendor/chart.js',
  './js/vendor/wow.js',
  './js/dist/scrolling-navbar.js',
  './js/vendor/waves.js',
  './js/dist/forms-free.js',
  './js/vendor/enhanced-modals.js'
];
